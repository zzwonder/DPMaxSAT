import itertools
from boolean_formula import Formula
import sys
import pypblib
import pysat
from pysat.pb import *
#from pysat.card import *
import os

def xor2cnf(xor, block_var, weight):
    if len(xor)==3:
        return [[weight, block_var, -xor[0],-xor[1],xor[2]], [weight, block_var, xor[0],-xor[1],-xor[2]], [weight, block_var, -xor[0],xor[1],-xor[2]],[weight, block_var, xor[0],xor[1],xor[2]] ]
       # return [[ block_var, -xor[0],-xor[1],xor[2]], [block_var, xor[0],-xor[1],-xor[2]], [ block_var, -xor[0],xor[1],-xor[2]],[block_var, xor[0],xor[1],xor[2]] ]
    if len(xor)==2:
        #return [[ block_var, xor[0],xor[1]],[ block_var, -xor[0],-xor[1]]]
        return [[weight, block_var, xor[0],xor[1]],[weight, block_var, -xor[0],-xor[1]]]

def de_xor(llist,start):
    oldstart = start
    exactFlag = 0
    if len(llist)<=3:
        return [list(llist),],start
    else:
        clist = []
        i = 0
        while True:
            if i>=len(llist):
                break
            elif i==len(llist)-1:
                exactFlag = 1
                break
            else:
                clist.append([-llist[i],llist[i+1],start+1])
                start+=1
                i+=2
    if exactFlag == 1:
        flist,_ = de_xor([llist[-1]] + list(range(oldstart+1,start+1)),start)
    else:
        flist,_ = de_xor(range(oldstart+1,start+1),start)
    return clist+flist,_

def kxor(n):
    return de_xor(range(1,n+1),n+1)
def xor100():
    f = open('benchmarks/sxor/x10.cnf','w+')
    n=10
    clauses,nv = kxor(n)
    f.write('p cnf '+repr(nv)+' '+repr(len(clauses))+'\n')
    for c in clauses:
        f.write('x ')
        for l in c:
            f.write(repr(l)+' ')
        f.write('0\n')

def sign(a):
    if a>0: return 1
    return -1

def xor_blow(filepath,topath):
    group_sat = 1
    encoding_no = 0
    f = open(filepath,'r+')
    g = open(topath,'w+')
    lines = f.readlines()
    nvars = 0
    nclas = 0
    pbs = []
    clause_list = []
    start = 0
    m = 0
    block_variables = []
    for line in lines:
        split = line.split()
        if len(split) == 0: continue
        if split[0] == 'p':
            nvars = int(split[2])
            start = nvars
        if split[0] == 'c': continue
        if split[0][0] == '[':
            if split[2][0] == 'x' and split[1] != "x":  #card or pb
                pbs.append(line)
                m += 1 
            else: # xor
                weight = int(split[0][1:-1])
                xorClause = split[2:-1]
                xorClause = [int(i) for i in xorClause]
                print("xor clause = "+repr(xorClause))
                blow_clauses,_ = de_xor(xorClause,start)
                start = _
                start += 1
                for b in blow_clauses:
                    cnfs = xor2cnf(b, start, weight)
                    clause_list.append(cnfs)
                    m += len(cnfs)
                block_variables.append((weight,start))
    g.write('* #variable= '+repr(start)+' #constraint= '+repr(m + len(block_variables))+ ' \n')
    for line in pbs:
        g.write(line)
    for cg in clause_list:
        for c in cg:
            c = c[1:]
            g.write('[1] ')
            numneg = sum([i<0 for i in c])
            for item in c:
                if item < 0:
                    g.write( '-1 x'+repr(-item)+' ')
                else:
                    g.write( '+1 x'+repr(item)+' ')
            g.write('>= ' + repr(1-numneg) + ' ;\n')
    for pair in block_variables:
        g.write('[' + repr(pair[0])+"] -1 x" + repr(pair[1])+" >= 0 ;\n")
    f.close()
    g.close()

xor_blow(sys.argv[1],sys.argv[2])
