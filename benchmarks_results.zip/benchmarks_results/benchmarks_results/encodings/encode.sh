#!/bin/bash
function do_exp(){
for file in `ls $1`
do
    if [ -d $1"/"$file ]
    then
        do_exp $1"/"$file $2 $3
    else
        filename=$(basename $1"/"$file)
        if [[ $filename != *.hwcnf ]]
        then
            continue
        fi
        filepath=$1"/"$file
	echo $filepath
        python3 $3 $filepath $2/$filename
     fi
done
}
if [[ ! -d $2 ]] ;
then
	mkdir -p $2
fi
do_exp $1 $2 $3 
# do_exp direct name 
