import itertools
from boolean_formula import Formula
import sys


def xor_blow(filepath,topath):
    print('Now encoding: ' + filepath)
    f = open(filepath,'r+')
    g = open(topath,'w+')
    lines = f.readlines()
    start = 0
    inf = 100000000
    clauses = []
    cost_string = ""
    for line in lines:
        weight = 0
        split = line.split()
        rhs = 0
        if len(split) == 0:
            continue
        if split[0] == '*':
            if split[1] == "#variable=":
                nv = int(split[2])
                nc = int(split[4])
                start = nv
                continue
        if split[0][0] == '*':
            continue
        if split[0] == "soft:": continue
        if split[0][0] == '[':
            weight = split[0]
            weight = int(weight[1:-1])
            split = split[1:]
            rhs = int(split[-2])
            comparator = split[-3]
            start += 1
            if comparator == "<=":
                for i in range(int((len(split)-3)/2)):
                    sgn = ''
                    if int(split[i*2]) < 0: sgn = '+'
                    split[i*2] = sgn+repr(-int(split[i*2]))
                clauses.append(' '.join(split[0:-3]) + " +" + repr(inf) + " x"+repr(start)+" >= "+repr(-rhs)+' ;\n')
            elif comparator == ">=": 
                clauses.append(' '.join(split[0:-3]) + " +" + repr(inf) + " x"+repr(start)+" >= "+repr(rhs)+' ;\n')
            elif comparator == "=":
                clauses.append(' '.join(split[0:-3]) +" +" + repr(inf) + " x"+repr(start)+" >= "+repr(rhs)+' ;\n')
                for i in range(int((len(split)-3)/2)):
                    sgn = ''
                    if int(split[i*2]) < 0: sgn = '+'
                    split[i*2] = repr(-int(split[i*2]))
                clauses.append(' '.join(split[0:-3]) + " +" + repr(inf) + " x"+repr(start)+" >= "+repr(-rhs)+' ;\n')
            else:
                print("unrecognized comparator: "+comparator)
            cost_string += ("+"+repr(weight)+" x"+repr(start)+" ")
        else:
            clauses.append(line)
    g.write("* #variable= "+repr(start) + " #constraint= "+repr(len(clauses))+'\n')
    g.write("min: "+cost_string+";\n")
    for clause in clauses:
        g.write(clause)
    f.close()
    g.close()

xor_blow(sys.argv[1],sys.argv[2])
