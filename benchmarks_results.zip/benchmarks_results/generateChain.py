import numpy as np
import os
def generateChain(n,k):
    for index in range(1,2):
        filename = 'n'+repr(n)+'_k'+repr(k)+'_'+repr(index)+'.hwcnf'
        f = open("chain/vanilla/cardxor/"+filename,'w+')
        m = n-k
        f.write("p hwcnf "+repr(n)+" "+repr(m)+' 100000 \n')
        for i in range(1,n-k+1):
            conType = 'u'
            weight = np.random.randint(n) + 1
            weight = 1
            if np.random.randint(2) > 1: # xor constraint
                conType = 'x'
                f.write('[' + repr(weight) + ']' + ' x ')
            else: # card constraint
                f.write('[' + repr(weight) + '] ')
                conType = 'p'
            literal = [i+j for j in range(k)]
            if conType == 'x':
                for l in literal:
                    if np.random.randint(2) == 0:
                        f.write('-')
                    f.write(repr(l)+' ')
                f.write('0\n')
            elif conType == 'p':
                rhs = np.random.randint(k)
                for l in literal:
                    f.write('+1 x'+repr(l)+' ')
                f.write(' = '+repr(rhs)+' ;\n')

nlist = [100, 200, 400, 600, 800, 1000, 1200]
klist = [5, 10, 15 ,20, 25, 30]

for n in nlist:
    for k in klist:
        generateChain(n,k)
