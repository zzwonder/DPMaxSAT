import os
import numpy as np
import random

def cnfxor(n, cnfden, xorden, cardden, k, problem):
    directory = "../hybrid_random/" + problem + "xor/n"+repr(n);
    weightedFlag = 0
    if not os.path.exists(directory): os.makedirs(directory)
    for i in range(1,21):
            mcnf = int(cnfden * n)
            mxor = int(xorden * n)
            if problem == 'card':
                mcard = int(cardden * n)
            else: mcard = 0
            if problem == 'pb':
                mpb = int(cardden * n)
            else: 
                mpb = 0
            f = open(directory+ "/uw_n" + repr(n) + "_" + problem +"den" + repr(cardden) + "_xorden" + repr(xorden) + "_k" + repr(k) + "_" + repr(i) + ".hwcnf","w")
            f.write("p hwcnf "+repr(n)+" "+repr( mcnf + mcard + mxor )+' 1000000\n')
            numCNFClauses = 0
            while numCNFClauses < mcnf:
                if weightedFlag == 1:
                    weight = np.random.randint(n) + 1
                else:
                    weight = 1
                f.write("["+repr(weight)+"] ")
                tempC = random.sample(range(n), k)
                for j in range(k):
                    parity = np.random.randint(2)
                    if parity == 1:
                        f.write(repr(1+tempC[j]))
                        f.write(" ")
                    elif parity == 0:
                        f.write(repr(-1-tempC[j]))
                        f.write(" ")
                f.write("0\n")
                numCNFClauses += 1
            numCardClauses = 0
            while numCardClauses < mcard:
                if weightedFlag == 1:
                    weight = np.random.randint(n) + 1
                else:
                    weight = 1
                f.write("["+repr(weight)+"] ")
                tempC = random.sample(range(n), k)
                comparator = np.random.randint(2)
                for j in range(k):
                    rhs = np.random.randint(k-1) + 1 
                    f.write('+1 x' + repr(1 + tempC[j]) +' ') 
                if comparator == 0: f.write(">= " + repr(rhs) + " ;\n")
                else: f.write("<= " + repr(rhs) +" ;\n")
                numCardClauses += 1

            numPbClauses = 0
            while numPbClauses < mpb:
                if weightedFlag == 1:
                    weight = np.random.randint(n) + 1
                else: weight = 1
                f.write("["+repr(weight)+"] ")
                tempC = random.sample(range(n), k)
                comparator = np.random.randint(2)
                for j in range(k):
                    rhs = np.random.randint(k-1) + 1 
                    coef = np.random.randint(n) + 1
                    sign = np.random.randint(2)
                    if sign == 1: 
                        f.write('+' + repr(coef)+  ' x' + repr(1 + tempC[j]) +' ')
                    else:
                        f.write('-' + repr(coef)+  ' x' + repr(1 + tempC[j]) +' ') 
                if comparator == 0: f.write(">= 0 ;\n")
                else: f.write("<= 0 ;\n")
                numPbClauses += 1
            numXORClauses = 0
            while numXORClauses < mxor:
                if weightedFlag == 1:
                    weight = np.random.randint(n) + 1
                else: weight = 1
                f.write("["+repr(weight)+"] ")
                parity = np.random.randint(2)
                tempC = random.sample(range(n), k)
                f.write("x ")
                for j in range(k):
                    if j == 0:
                        if parity == 1:
                            f.write(repr(1+tempC[j]))
                            f.write(" ")
                        elif parity == 0:
                            f.write(repr(-1-tempC[j]))
                            f.write(" ")
                    else:
                        f.write(repr(1+tempC[j]))
                        f.write(" ")
                f.write("0\n")
                numXORClauses += 1

klist = [5,7]
nlist = [50, 75, 100]
carddenlist = [0.3,0.4,0.5,0.6,0.7,0.8,0.9,1]
xordenlist = [0.3,0.4,0.5,0.6,0.7,0.8,0.9,1]
for n in nlist:
    for cardden in carddenlist:
        for xorden in xordenlist:
            for k in klist:
                cnfxor(n, 0, xorden, cardden, k, 'card')
                cnfxor(n, 0, xorden, cardden, k, 'pb')
