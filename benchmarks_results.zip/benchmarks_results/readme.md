## Experiment 1

This directory contains the benchmarks of "Low-width Chain Formulas" used in Experiment 1. We also include code for generating the instances.

You can find chain instances in .hwcnf format in ./chain/

You can generate those instances and encode them into .wcnf, .wbo and .pbo with the python code in ./encodings. Pysat and PBlib are required to be installed for running the encoding python scripts.

In encodings/, run
	
	python3  generateChain.py 

to generate the chain formulas.

In encodings/, run the following to encode .hwcnf files to CNF (.wcnf) files.

	./encode.sh ../chain/vanilla/cardxor ../chain/CNF/cardxor HWCNF2CNF.py

In encodings/, run the following to encode .hwcnf files to WBO (.wbo) files.
	
	./encode.sh ../chain/vanilla/cardxor ../chain/WBO/cardxor HWCNF2WBO.py

In encodings/, run the following to encode .wbo files to PBO (.pbo) files.

	./encode.sh ../chain/WBO/cardxor ../chain/PBO/cardxor HWCNF2WBO.py

## Experiment 2

To generate instances used in Experiment 2, run the following:

	python3 generateRandom.py


## Experiment 3

The benchmarks used in Experiment 3 (QBF/Min-MaxSAT) can be found from the official website of recent QBF evaluations (2-QBF Track).	
